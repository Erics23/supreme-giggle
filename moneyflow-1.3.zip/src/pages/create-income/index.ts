export { CreateIncomePage } from "./ui/create-income-page";
