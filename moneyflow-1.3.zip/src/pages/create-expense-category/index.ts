export { CreateExpenseCategoryPage } from "./ui/create-expense-category-page";
