export { TextSizeSettingsPage } from "./ui/text-size-settings-page";
