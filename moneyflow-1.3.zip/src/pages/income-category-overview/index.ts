export { IncomeCategoryOverviewPage } from "./ui/income-category-overview-page";
