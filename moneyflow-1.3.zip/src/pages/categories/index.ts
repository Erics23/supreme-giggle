export { CategoriesPage } from "./ui/categories-page";
