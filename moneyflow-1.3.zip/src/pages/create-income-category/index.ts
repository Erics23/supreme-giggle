export { CreateIncomeCategoryPage } from "./ui/create-income-category-page";
