import { V2Backup } from "./versions/v2/v2-backup.schema";

export type Backup = V2Backup;
