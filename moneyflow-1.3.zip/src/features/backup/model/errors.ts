export class BackupValidationError extends Error {}
