export { Input, type InputProps } from "./input";
