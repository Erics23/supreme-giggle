export { Link } from "./link";
export { ExternalLink } from "./external-link";
export type { LinkProps } from "./link";
