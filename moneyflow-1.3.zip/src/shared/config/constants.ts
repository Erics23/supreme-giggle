export const APP_VERSION = import.meta.env.VITE_APP_VERSION;
export const APP_RELEASES_LINK = import.meta.env.VITE_APP_RELEASES_LINK;
export const APP_GITHUB_LINK = import.meta.env.VITE_APP_GITHUB_LINK;
