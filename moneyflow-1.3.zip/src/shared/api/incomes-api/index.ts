import { PreferencesIncomesAPI } from "./preferences-incomes-api";
export type { IncomesDTO } from "./dtos";

export const incomesApi = new PreferencesIncomesAPI();
