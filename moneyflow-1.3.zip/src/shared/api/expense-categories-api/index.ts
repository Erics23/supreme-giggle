import { PreferencesExpenseCategoriesAPI } from "./preferences-expense-categories-api";
export type { ExpenseCategoriesDTO } from "./dtos";

export const expenseCategoriesApi = new PreferencesExpenseCategoriesAPI();
