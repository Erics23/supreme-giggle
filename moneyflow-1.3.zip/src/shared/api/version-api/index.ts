import { PreferencesVersionAPI } from "./preferences-version-api";
export { type DeviceDBVersion, DBVersion } from "./dtos";

export const versionApi = new PreferencesVersionAPI();
