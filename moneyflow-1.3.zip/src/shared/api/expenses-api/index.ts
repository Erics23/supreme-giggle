import { PreferencesExpensesAPI } from "./preferences-expenses-api";
export type { ExpensesDTO } from "./dtos";

export const expensesApi = new PreferencesExpensesAPI();
