export class MigrationError extends Error {}
