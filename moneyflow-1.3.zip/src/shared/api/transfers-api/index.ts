import { PreferencesTransfersAPI } from "./preferences-transfers-api";
export type { TransfersDTO } from "./dtos";

export const transfersApi = new PreferencesTransfersAPI();
