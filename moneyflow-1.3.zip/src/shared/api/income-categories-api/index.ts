import { PreferencesIncomeCategoriesAPI } from "./preferences-income-categories-api";
export type { IncomeCategoriesDTO } from "./dtos";

export const incomeCategoriesApi = new PreferencesIncomeCategoriesAPI();
