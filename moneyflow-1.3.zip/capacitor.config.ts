import { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.hisabkhata.app",
  appName: "Cashier X",
  webDir: "dist",
  server: {
    url: "http://181.214.240.87:5173",
    cleartext: true,
  },
  plugins: {
    SplashScreen: {
      launchAutoHide: true,
    },
  },
};

export default config;
