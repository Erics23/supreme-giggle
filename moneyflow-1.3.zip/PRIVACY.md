We don't collect your data. All Money Flow app data is stored locally on your device and is never transferred to us.
